clc;clear;close all


% A1=[0 1;-9.2 -6.6];
% A2=[0 1;-10.8 -7.4];
% B1=[1;0]; B2=B1;
% C=[0.4 0];
% n1=2; n2=1; n3=2;


%%% 7_motor 
Jm = 2.8e-5; Bm = 20*Jm; 
Fs = 3.25e-2; Fc = 1.76e-2; vs = 2.73; fv1 = 2.5e-4; fv2 = -9.252e-7; fv3 = 1.72e-9;
A = -Bm/Jm; B = 1/Jm; 
A1 = -Bm/Jm - fv1; 
A2 = -Bm/Jm - fv1 - fv3*4900; 
B1 = 1/Jm; B2 = 1/Jm;
C = 1; 
n1=1; n2=1; n3=1;


wc=100;
rhowc=100;

alpha = 155.9; beta = 302.1;


% Matrices to be defined
setlmis([]);
X=lmivar(1,[n1,1]); 
barP2=lmivar(1,[n2,1]); 
P31=lmivar(1,[n1,1]); P32=lmivar(1,[n1,1]); 
barQ=lmivar(1,[n2,1]); 
K11=lmivar(2,[n2,n1]); K21=lmivar(2,[n2,n1]); 
K12=lmivar(1,[n2,1]); K22=lmivar(1,[n2,1]); 
X11=lmivar(1,[n1,1]); X12=lmivar(1,[n1,1]); X21=lmivar(1,[n1,1]); X22=lmivar(1,[n1,1]);
M=lmivar(1,[n1,1]); 
barL1=lmivar(2,[n1,n2]); barL2=lmivar(2,[n1,n2]); 

%LMI conditions
lmiterm([1 1 1 X],A1,alpha,'s'); lmiterm([1 1 1 K11],B1,alpha,'s'); 
lmiterm([1 1 2 X],-wc*alpha,C'); 
lmiterm([1 1 3 K12],B1,beta);
lmiterm([1 2 2 barP2],-1,wc,'s');
lmiterm([1 2 3 barQ],wc,beta); 
lmiterm([1 2 4 barP2],1,1);
lmiterm([1 3 3 barQ],-1,beta);
lmiterm([1 4 4 barQ],-1,beta);

lmiterm([2 1 1 X],A2,alpha,'s'); lmiterm([2 1 1 K21],B2,alpha,'s'); 
lmiterm([2 1 2 X],-wc*alpha,C'); 
lmiterm([2 1 3 K22],B2,beta);
lmiterm([2 2 2 barP2],-1,wc,'s');
lmiterm([2 2 3 barQ],wc,beta); 
lmiterm([2 2 4 barP2],1,1);
lmiterm([2 3 3 barQ],-1,beta);
lmiterm([2 4 4 barQ],-1,beta);

lmiterm([3 1 1 X],A1,alpha,'s'); lmiterm([3 1 1 K21],B1,alpha,'s'); 
lmiterm([3 1 1 X],A2,alpha,'s'); lmiterm([3 1 1 K11],B2,alpha,'s');
lmiterm([3 1 2 X],-wc*alpha,C'); lmiterm([3 1 2 X],-wc*alpha,C'); 
lmiterm([3 1 3 K22],B1,beta); lmiterm([3 1 3 K12],B2,beta);
lmiterm([3 2 2 barP2],-1,wc,'s'); lmiterm([3 2 2 barP2],-1,wc,'s'); 
lmiterm([3 2 3 barQ],beta,wc); lmiterm([3 2 3 barQ],beta,wc); 
lmiterm([3 2 4 barP2],1,1); lmiterm([3 2 4 barP2],1,1); 
lmiterm([3 3 3 barQ],-1,beta); lmiterm([3 3 3 barQ],-1,beta); 
lmiterm([3 4 4 barQ],-1,beta); lmiterm([3 4 4 barQ],-1,beta);

lmiterm([-10 1 1 X],1,1);
lmiterm([-11 1 1 barQ],1,1);
lmiterm([-12 1 1 barP2],1,1);

lmisys=getlmis;
[tmin,xfeas]=feasp(lmisys);
tmin

X=dec2mat(lmisys,xfeas,X);
barP2=dec2mat(lmisys,xfeas,barP2);
barQ=dec2mat(lmisys,xfeas,barQ);
K11=dec2mat(lmisys,xfeas,K11); K21=dec2mat(lmisys,xfeas,K21);
K12=dec2mat(lmisys,xfeas,K12); K22=dec2mat(lmisys,xfeas,K22);
P31=dec2mat(lmisys,xfeas,P31); P32=dec2mat(lmisys,xfeas,P32); 
X11=dec2mat(lmisys,xfeas,X11); X22=dec2mat(lmisys,xfeas,X22); X12=dec2mat(lmisys,xfeas,X12); X21=dec2mat(lmisys,xfeas,X21);
M=dec2mat(lmisys,xfeas,M);
barL1=dec2mat(lmisys,xfeas,barL1); barL2=dec2mat(lmisys,xfeas,barL2);

k12=K12*inv(barQ)
k22=K22*inv(barQ)
k11=K11*inv(X)+k12*C
k21=K21*inv(X)+k22*C