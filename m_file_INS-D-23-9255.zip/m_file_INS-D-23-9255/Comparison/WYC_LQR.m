% %%% 7_motor 
% Jm = 2.8e-5; Bm = 20*Jm; 
% A = -Bm/Jm; B = 1/Jm; C = 1;


QL = diag([1e6]);
RL = 1;
[SL,IL,gL] = care(A',C',QL,RL);

L = (inv(RL)*C*SL)'