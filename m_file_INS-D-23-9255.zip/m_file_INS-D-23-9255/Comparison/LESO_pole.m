clc;clear;close all


A1 = [0 1; -9.2 -6.6];
A2 = [0 1; -10.8 -7.4];
B1 = [1; 0]; B2 = B1;
A = [0 1; -10 -7];
B = [1; 0];
C = [0.4 0]; 
Bd = B;

K1_p = 172.6906;
K2_p = [-0.7165 1.9297];  
K1_n = 171.6266;
K2_n = [-0.6772 1.4186];  


% Jm = 2.8e-5; Bm = 20*Jm; 
% A = -Bm/Jm; B = 1/Jm; C = 1;
% 
% K1_p = 0.01;
% K2_p = -1e-4;  
% K1_n = K1_p;
% K2_n = K2_p;  

D = 0;
sys = ss(A,B,C,D) % Continuous-time state-space model
G = zpk(sys) % Continuous-time zero/pole/gain model
pole(G)

n = size(A,1);
p = size(B,1);
q = size(C,1);

Abar = [A B; zeros(q,n) zeros(q)];
Bbar = [B; zeros(q)];
Cbar = [C zeros(q)];

% po = -550;
% po = -1000;
po = -100;
J = [po, po, po];

K = - acker(A, B, [-100,-100]);
L = acker(Abar', Cbar', J)'
% Kd = - pinv(B);
Kd = -1;
Kz = [K Kd];

% po = -550;
% J = [po, po];
% 
% K = - acker(A, B, [-100]);
% L = acker(Abar', Cbar', J)'
% Kd = - pinv(B);
% Kz = [K Kd];
