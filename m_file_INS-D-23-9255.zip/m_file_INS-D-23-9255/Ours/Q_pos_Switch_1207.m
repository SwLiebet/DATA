AF=-200*eye(p); BF=200*eye(p); CF=eye(p);

Adbar=[zeros(n) zeros(n,q) zeros(n) zeros(n,p); 
       zeros(q,n) wc*eye(q) zeros(q,n) zeros(q,p); 
       zeros(n) zeros(n,q) zeros(n) zeros(n,p); 
       zeros(p,n) zeros(p,q) zeros(p,n) zeros(p)];
Cbar=[zeros(q,n) zeros(q) C zeros(q,p)];
Bbar1 = [B1; zeros(q,p); zeros(n,p); zeros(p)];
Bbar2 = [B2; zeros(q,p); zeros(n,p); zeros(p)];
Abar1 = [A1, zeros(n,q), zeros(n), -B1*CF;
        -wc*C, -wc*eye(q), zeros(q,n), zeros(q,p);
        zeros(n), zeros(n,q), A1, -B1*CF;
        zeros(p,n), zeros(p,q), zeros(p,n), AF+BF*CF];
Abar2 = [A2, zeros(n,q), zeros(n), -B2*CF;
        -wc*C, -wc*eye(q), zeros(q,n), zeros(q,p);
        zeros(n), zeros(n,q), A2, -B2*CF;
        zeros(p,n), zeros(p,q), zeros(p,n), AF+BF*CF];

Kbar1_p = [K2_p - K1_p*C, zeros(p,q), -K2_p, zeros(p)];
Gbar1_p = Abar1 + Bbar1*Kbar1_p;
Gbar2_p = Abar2 + Bbar2*Kbar1_p;
eig(Gbar1_p);
eig(Gbar2_p);
Kbar2_p = [zeros(p,n), K1_p, zeros(p,n), zeros(p)];
Dbar1_p = Adbar + Bbar1*Kbar2_p;
Dbar2_p = Adbar + Bbar2*Kbar2_p;


gamma_p = 1e1; mu_p = 1e5; epsilon_p = 1e-3; psi_p = 1e-2; %WYC_TFS

% gamma_p = 6e8; mu_p = 1e0; epsilon_p = 1e-5; psi_p = 1e5; %ʵ��



% Matrices to be defined
setlmis([]);
S1_p=lmivar(1,[n+q+n+p,1]); S2_p=lmivar(1,[n+q+n+p,1]);
R_p=lmivar(1,[n+q+n+p,1]); 
[Z41_p,n3,xqp31_p]=lmivar(1,[n+q,1]);
[Z433_p,n3,xqp333_p]=lmivar(1,[n,1]);
[Z434_p,n3,xqp334_p]=lmivar(2,[n,p]);
[Z444_p,n3,xqp344_p]=lmivar(1,[p,1]);
[Z42_p,n3,xqp32_p]=lmivar(3,[xqp333_p,xqp334_p;xqp334_p',xqp344_p]);
[Z4_p,n3,xqp3_p]=lmivar(3,[xqp31_p,zeros(n+q,n+p);
                      zeros(n+p,n+q),xqp32_p]);
[W3_p,n3,xqpw_p]=lmivar(2,[n+p,q]); 
[Wbar3_p,n3,xqpwbar_p]=lmivar(3,[zeros(n+q,q);xqpw_p]);

%LMI conditions
lmiterm([1 1 1 R_p],1,1); lmiterm([1 1 1 Z4_p],psi_p,Gbar1_p,'s'); lmiterm([1 1 1 Wbar3_p],psi_p,Cbar,'s'); 
lmiterm([1 1 2 Z4_p],psi_p,Dbar1_p);
lmiterm([1 1 3 S1_p],1,1); lmiterm([1 1 3 Z4_p],-1,psi_p); 
lmiterm([1 1 3 -Z4_p],Gbar1_p',epsilon_p*psi_p); lmiterm([1 1 3 -Wbar3_p],Cbar',epsilon_p*psi_p); 
lmiterm([1 2 2 R_p],-1,1);
lmiterm([1 2 3 -Z4_p],Dbar1_p',epsilon_p*psi_p);
lmiterm([1 3 3 Z4_p],-epsilon_p,psi_p,'s');

lmiterm([2 1 1 R_p],1,1); lmiterm([2 1 1 Z4_p],psi_p,Gbar2_p,'s'); lmiterm([2 1 1 Wbar3_p],psi_p,Cbar,'s'); 
lmiterm([2 1 2 Z4_p],psi_p,Dbar2_p);
lmiterm([2 1 3 S1_p],1,1); lmiterm([2 1 3 Z4_p],-1,psi_p); 
lmiterm([2 1 3 -Z4_p],Gbar2_p',epsilon_p*psi_p); lmiterm([2 1 3 -Wbar3_p],Cbar',epsilon_p*psi_p); 
lmiterm([2 2 2 R_p],-1,1);
lmiterm([2 2 3 -Z4_p],Dbar2_p',epsilon_p*psi_p);
lmiterm([2 3 3 Z4_p],-epsilon_p,psi_p,'s');

lmiterm([4 1 1 S1_p],1,1); lmiterm([4 1 1 S2_p],-1,1);

lmiterm([-6 1 1 S1_p],1,1);
lmiterm([-7 1 1 S2_p],1,1);
lmiterm([-8 1 1 R_p],1,1);
lmiterm([-10 1 1 Z4_p],1,1);
lmiterm([-11 1 1 Z41_p],1,1);
lmiterm([-14 1 1 Z42_p],1,1);
lmiterm([-12 1 1 Z433_p],gamma_p,1);
lmiterm([-13 1 1 Z444_p],mu_p,1);

lmisys=getlmis;
[tmin,xfeas]=feasp(lmisys);
tmin
y2_p=tmin;

S1_p=dec2mat(lmisys,xfeas,S1_p); S2_p=dec2mat(lmisys,xfeas,S2_p); 
R_p=dec2mat(lmisys,xfeas,R_p); 
Z4_p=dec2mat(lmisys,xfeas,Z4_p);
Z41_p=dec2mat(lmisys,xfeas,Z41_p);
Z42_p=dec2mat(lmisys,xfeas,Z42_p);
Z433_p=dec2mat(lmisys,xfeas,Z433_p);
Z444_p=dec2mat(lmisys,xfeas,Z444_p);
Wbar3_p=dec2mat(lmisys,xfeas,Wbar3_p);
W3_p=dec2mat(lmisys,xfeas,W3_p);

L0_p=pinv(Z42_p)*W3_p;
L_p=-L0_p(1:n,1:q)
LL_p=L0_p(n+1:end,1:q);
K_p=pinv(BF)*LL_p
