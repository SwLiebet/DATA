
alpha_n = 1e2; beta_n = 1.4e3; delta_n = 6.951e-2; 

% alpha_n = 934; beta_n = 7562; delta_n = 0.1;  % ʵ��

% Matrices to be defined
setlmis([]);
[E11_n,n1,xn11_n]=lmivar(1,[n,1]);
[E12_n,n1,xn12_n]=lmivar(1,[q,1]);
[E1_n,n1,xn1_n]=lmivar(3,[xn11_n,zeros(n,q);
                      zeros(q,n),xn12_n]);
[E21_n,n2,xn21_n]=lmivar(1,[n,1]);
[E22_n,n2,xn22_n]=lmivar(1,[q,1]);
[E2_n,n2,xn2_n]=lmivar(3,[xn21_n,zeros(n,q);
                      zeros(q,n),xn22_n]);
X1_n=lmivar(1,[n+q,1]); X2_n=lmivar(1,[n+q,1]);
Y1_n=lmivar(1,[n+q,1]); 
Y2_n=lmivar(1,[n+q,1]);
[W1_n,n3,wb2_n]=lmivar(2,[p,n]); Wbar1_n=lmivar(3,[wb2_n,zeros(p)]); 
[W2_n,n4,wb1_n]=lmivar(1,[p,1]); Wbar2_n=lmivar(3,[zeros(p,n),wb1_n]); 

%LMI conditions
lmiterm([1 1 1 Y1_n],1,1); lmiterm([1 1 1 E1_n],Atilde1,1,'s'); lmiterm([1 1 1 Wbar1_n],Btilde1,1,'s'); 
lmiterm([1 1 2 E2_n],Ad,1); lmiterm([1 1 2 Wbar2_n],Btilde1,1); lmiterm([1 1 2 -E1_n],1,Atilde1'); lmiterm([1 1 2 -Wbar1_n],1,Btilde1'); 
lmiterm([1 1 3 X1_n],1,1); lmiterm([1 1 3 E1_n],-1,1); lmiterm([1 1 3 E1_n],delta_n,Atilde1'); lmiterm([1 1 3 -Wbar1_n],delta_n,Btilde1');
lmiterm([1 2 2 Y2_n],-1,1); lmiterm([1 2 2 E2_n],Ad,1,'s'); lmiterm([1 2 2 Wbar2_n],Btilde1,1,'s'); 
lmiterm([1 2 3 E1_n],-1,1); lmiterm([1 2 3 E2_n],delta_n,Ad'); lmiterm([1 2 3 -Wbar2_n],delta_n,Btilde1');
lmiterm([1 3 3 E1_n],-delta_n,1,'s');

lmiterm([2 1 1 Y1_n],1,1); lmiterm([2 1 1 E1_n],Atilde2,1,'s'); lmiterm([2 1 1 Wbar1_n],Btilde2,1,'s'); 
lmiterm([2 1 2 E2_n],Ad,1); lmiterm([2 1 2 Wbar2_n],Btilde2,1); lmiterm([2 1 2 -E1_n],1,Atilde2'); lmiterm([2 1 2 -Wbar1_n],1,Btilde2'); 
lmiterm([2 1 3 X2_n],1,1); lmiterm([2 1 3 E1_n],-1,1); lmiterm([2 1 3 E1_n],delta_n,Atilde2'); lmiterm([2 1 3 -Wbar1_n],delta_n,Btilde2');
lmiterm([2 2 2 Y2_n],-1,1); lmiterm([2 2 2 E2_n],Ad,1,'s'); lmiterm([2 2 2 Wbar2_n],Btilde2,1,'s'); 
lmiterm([2 2 3 E1_n],-1,1); lmiterm([2 2 3 E2_n],delta_n,Ad'); lmiterm([2 2 3 -Wbar2_n],delta_n,Btilde2');
lmiterm([2 3 3 E1_n],-delta_n,1,'s');

lmiterm([-4 1 1 X1_n],1,1); lmiterm([-4 1 1 X2_n],1,-1);

lmiterm([-6 1 1 X1_n],1,1); 
lmiterm([-7 1 1 X2_n],1,1);
lmiterm([-8 1 1 Y1_n],1,1); 
lmiterm([-9 1 1 Y2_n],1,1);
lmiterm([-10 1 1 E1_n],1,1);
lmiterm([-5 1 1 E2_n],1,1);
lmiterm([-11 1 1 E11_n],alpha_n,1);
lmiterm([-12 1 1 E22_n],beta_n,1);

lmisys=getlmis;
[tmin,xfeas]=feasp(lmisys);
tmin
y1_n=tmin;

E1_n=dec2mat(lmisys,xfeas,E1_n);
E2_n=dec2mat(lmisys,xfeas,E2_n);
Wbar1_n=dec2mat(lmisys,xfeas,Wbar1_n); 
Wbar2_n=dec2mat(lmisys,xfeas,Wbar2_n); 
X1_n=dec2mat(lmisys,xfeas,X1_n);
X2_n=dec2mat(lmisys,xfeas,X2_n); 
Y1_n=dec2mat(lmisys,xfeas,Y1_n);
Y2_n=dec2mat(lmisys,xfeas,Y2_n); 

k1_n=Wbar2_n*inv(E2_n);
K1_n=k1_n(1:p,n+1)

k2_n=Wbar1_n*inv(E1_n);
K2_n=k2_n(1:p,1:n) + K1_n*C