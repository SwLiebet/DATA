Af=-200*eye(p); Bf=200*eye(p); Cf=eye(p);
r1=1; u1=1e+0; g1=210; e3=0.0003967;
M=0.2/1.2;


% AK1=-Bm/(0.8*Jm)-fv1; 
% AK2=-Bm/(0.8*Jm)-fv1-fv3*4900; 
% BK1=1/(0.8*Jm); BK2=BK1;
% 
% NA1=Bm/(0.8*Jm); NA2=NA1;
% NB1=-1/(0.8*Jm); NB2=NB1;
% Mbar=[M; zeros(q,n); M; zeros(q,n); zeros(q,n)];
% N1bar11=[NA1+NB1*(Kp1-Ke1*C) zeros(n,q) -NB1*Kp1 zeros(n,q) -NB1*Cf];
% N1bar12=[NA1+NB1*(Kp2-Ke2*C) zeros(n,q) -NB1*Kp2 zeros(n,q) -NB1*Cf];
% N1bar21=[NA2+NB2*(Kp1-Ke1*C) zeros(n,q) -NB2*Kp1 zeros(n,q) -NB2*Cf];
% N1bar22=[NA2+NB2*(Kp2-Ke2*C) zeros(n,q) -NB2*Kp2 zeros(n,q) -NB2*Cf];
% N2bar11=[zeros(n) NB1*Ke1 zeros(n) zeros(n,q) zeros(n,q)];
% N2bar12=[zeros(n) NB1*Ke2 zeros(n) zeros(n,q) zeros(n,q)];
% N2bar21=[zeros(n) NB2*Ke1 zeros(n) zeros(n,q) zeros(n,q)];
% N2bar22=[zeros(n) NB2*Ke2 zeros(n) zeros(n,q) zeros(n,q)];

AK1=A1; AK2=A2; BK1=B1; BK2=BK1;

Atilde11=[AK1+BK1*(Kp1-Ke1*C) zeros(n,q) -BK1*Kp1 zeros(n,q) -BK1*Cf;
         -wc*C -wc zeros(q,n) zeros(q) zeros(q);
         zeros(n) zeros(n,q) AK1 zeros(n,q) -BK1*Cf;
         zeros(q,n) zeros(q) zeros(q,n) zeros(q) zeros(q);
         zeros(q,n) zeros(q) zeros(q,n) Bf Af+Bf*Cf];
Atilde12=[AK1+BK1*(Kp2-Ke2*C) zeros(n,q) -BK1*Kp2 zeros(n,q) -BK1*Cf;
         -wc*C -wc zeros(q,n) zeros(q) zeros(q);
         zeros(n) zeros(n,q) AK1 zeros(n,q) -BK1*Cf;
         zeros(q,n) zeros(q) zeros(q,n) zeros(q) zeros(q);
         zeros(q,n) zeros(q) zeros(q,n) Bf Af+Bf*Cf];
Atilde21=[AK2+BK2*(Kp1-Ke1*C) zeros(n,q) -BK2*Kp1 zeros(n,q) -BK2*Cf;
         -wc*C -wc zeros(q,n) zeros(q) zeros(q);
         zeros(n) zeros(n,q) AK2 zeros(n,q) -BK2*Cf;
         zeros(q,n) zeros(q) zeros(q,n) zeros(q) zeros(q);
         zeros(q,n) zeros(q) zeros(q,n) Bf Af+Bf*Cf];
Atilde22=[AK2+BK2*(Kp2-Ke2*C) zeros(n,q) -BK2*Kp2 zeros(n,q) -BK2*Cf;
         -wc*C -wc zeros(q,n) zeros(q) zeros(q);
         zeros(n) zeros(n,q) AK2 zeros(n,q) -BK2*Cf;
         zeros(q,n) zeros(q) zeros(q,n) zeros(q) zeros(q);
         zeros(q,n) zeros(q) zeros(q,n) Bf Af+Bf*Cf];
Ctilde=[zeros(q,n) zeros(q) C zeros(q) zeros(q)];
Adtilde11=[zeros(n) BK1*Ke1 zeros(n) zeros(n,q) zeros(n,q); 
         zeros(q,n) wc zeros(q,n) zeros(q) zeros(q); 
         zeros(n) zeros(n,q) zeros(n) zeros(n,q) zeros(n,q); 
         zeros(q,n) zeros(q) zeros(q,n) zeros(q) zeros(q);
         zeros(q,n) zeros(q) zeros(q,n) zeros(q) zeros(q)];
Adtilde12=[zeros(n) BK1*Ke2 zeros(n) zeros(n,q) zeros(n,q); 
         zeros(q,n) wc zeros(q,n) zeros(q) zeros(q); 
         zeros(n) zeros(n,q) zeros(n) zeros(n,q) zeros(n,q); 
         zeros(q,n) zeros(q) zeros(q,n) zeros(q) zeros(q);
         zeros(q,n) zeros(q) zeros(q,n) zeros(q) zeros(q)]; 
Adtilde21=[zeros(n) BK2*Ke1 zeros(n) zeros(n,q) zeros(n,q); 
         zeros(q,n) wc zeros(q,n) zeros(q) zeros(q); 
         zeros(n) zeros(n,q) zeros(n) zeros(n,q) zeros(n,q); 
         zeros(q,n) zeros(q) zeros(q,n) zeros(q) zeros(q);
         zeros(q,n) zeros(q) zeros(q,n) zeros(q) zeros(q)];
Adtilde22=[zeros(n) BK2*Ke2 zeros(n) zeros(n,q) zeros(n,q); 
         zeros(q,n) wc zeros(q,n) zeros(q) zeros(q); 
         zeros(n) zeros(n,q) zeros(n) zeros(n,q) zeros(n,q); 
         zeros(q,n) zeros(q) zeros(q,n) zeros(q) zeros(q);
         zeros(q,n) zeros(q) zeros(q,n) zeros(q) zeros(q)];     


% Matrices to be defined
setlmis([]);
[N11_p,n31,xn11_p]=lmivar(1,[n+q,1]);
[N1211_p,n31,xn1211_p]=lmivar(1,[n,1]);
[N1212_p,n31,xn1212_p]=lmivar(2,[n,q]);
[N1213_p,n31,xn1213_p]=lmivar(2,[n,q]);
[N1222_p,n31,xn1222_p]=lmivar(1,[q,1]);
[N1223_p,n31,xn1223_p]=lmivar(1,[q,1]);
[N1233_p,n31,xn1233_p]=lmivar(1,[q,1]);
[N13_p,n31,xn13_p]=lmivar(3,[xn1211_p,xn1212_p,xn1213_p;
                             xn1212_p',xn1222_p,xn1223_p;
                             xn1213_p',xn1223_p',xn1233_p]);
[N1_p,n31,xqp3_p]=lmivar(3,[xn11_p,zeros(n+q,n+q+q);
                            zeros(n+q+q,n+q),xn13_p]);
P1_p=lmivar(1,[n+q+n+q+q,1]); P2_p=lmivar(1,[n+q+n+q+q,1]);
Q1_p=lmivar(1,[n+q+n+q+q,1]); Q2_p=lmivar(1,[n+q+n+q+q,1]);
[W3_p,n33,xw_p]=lmivar(2,[n+q+q,q]); 
[Wtilde3_p,n33,xwtilde_p]=lmivar(3,[zeros(n,q);zeros(q);xw_p]);
del_p=lmivar(1,[1,1]);

lmiterm([1 1 1 Q1_p],1,1); 
lmiterm([1 1 1 N1_p],1,Atilde11,'s'); lmiterm([1 1 1 Wtilde3_p],1,Ctilde,'s');
lmiterm([1 1 2 N1_p],1,Adtilde11);
lmiterm([1 1 3 P1_p],1,1); lmiterm([1 1 3 N1_p],-1,1); 
lmiterm([1 1 3 -N1_p],Atilde11',e3); lmiterm([1 1 3 -Wtilde3_p],Ctilde',e3); 
% lmiterm([1 1 4 N1_p],1,Mbar);
% lmiterm([1 1 5 del_p],1,N1bar11');
lmiterm([1 2 2 Q1_p],-1,1);
lmiterm([1 2 3 -N1_p],Adtilde11',e3);
% lmiterm([1 2 5 del_p],1,N2bar11');
lmiterm([1 3 3 N1_p],-e3,1,'s');
% lmiterm([1 3 4 N1_p],e3,Mbar);
% lmiterm([1 4 4 del_p],-1,1);
% lmiterm([1 5 5 del_p],-1,1);

lmiterm([2 1 1 Q2_p],1,1); 
lmiterm([2 1 1 N1_p],1,Atilde22,'s'); lmiterm([2 1 1 Wtilde3_p],1,Ctilde,'s');
lmiterm([2 1 2 N1_p],1,Adtilde22);
lmiterm([2 1 3 P2_p],1,1); lmiterm([2 1 3 N1_p],-1,1); 
lmiterm([2 1 3 -N1_p],Atilde22',e3); lmiterm([2 1 3 -Wtilde3_p],Ctilde',e3); 
% lmiterm([2 1 4 N1_p],1,Mbar);
% lmiterm([2 1 5 del_p],1,N1bar22');
lmiterm([2 2 2 Q2_p],-1,1);
lmiterm([2 2 3 -N1_p],Adtilde22',e3);
% lmiterm([2 2 5 del_p],1,N2bar22');
lmiterm([2 3 3 N1_p],-e3,1,'s');
% lmiterm([2 3 4 N1_p],e3,Mbar);
% lmiterm([2 4 4 del_p],-1,1);
% lmiterm([2 5 5 del_p],-1,1);

lmiterm([3 1 1 Q1_p],1,1); 
lmiterm([3 1 1 N1_p],1,Atilde12,'s'); lmiterm([3 1 1 Wtilde3_p],1,Ctilde,'s');
lmiterm([3 1 1 Q2_p],1,1); 
lmiterm([3 1 1 N1_p],1,Atilde21,'s'); lmiterm([3 1 1 Wtilde3_p],1,Ctilde,'s');
lmiterm([3 1 2 N1_p],1,Adtilde12); lmiterm([3 1 2 N1_p],1,Adtilde21);
lmiterm([3 1 3 P1_p],1,1); lmiterm([3 1 3 N1_p],-1,1);
lmiterm([3 1 3 -N1_p],Atilde12',e3); lmiterm([3 1 3 -Wtilde3_p],Ctilde',e3);
lmiterm([3 1 3 P2_p],1,1); lmiterm([3 1 3 N1_p],-1,1);
lmiterm([3 1 3 -N1_p],Atilde21',e3); lmiterm([3 1 3 -Wtilde3_p],Ctilde',e3);
% lmiterm([3 1 4 N1_p],1,Mbar); lmiterm([3 1 4 N1_p],1,Mbar);
% lmiterm([3 1 5 del_p],1,N1bar12'); lmiterm([3 1 5 del_p],1,N1bar21');
lmiterm([3 2 2 Q1_p],-1,1); lmiterm([3 2 2 Q2_p],-1,1);
lmiterm([3 2 3 -N1_p],Adtilde12',e3); lmiterm([3 2 3 -N1_p],Adtilde21',e3);
% lmiterm([3 2 5 del_p],1,N2bar12'); lmiterm([3 2 5 del_p],1,N2bar21');
lmiterm([3 3 3 N1_p],-e3,1,'s'); lmiterm([3 3 3 N1_p],-e3,1,'s');
% lmiterm([3 3 4 N1_p],e3,Mbar); lmiterm([3 3 4 N1_p],e3,Mbar);
% lmiterm([3 4 4 del_p],-1,1); lmiterm([3 4 4 del_p],-1,1);
% lmiterm([3 5 5 del_p],-1,1); lmiterm([3 5 5 del_p],-1,1);

lmiterm([4 1 1 P1_p],1,1); lmiterm([4 1 1 P2_p],-1,1);
lmiterm([5 1 1 Q1_p],1,1); lmiterm([5 1 1 Q2_p],-1,1);

lmiterm([-7 1 1 P1_p],1,1);
lmiterm([-8 1 1 P2_p],1,1);
lmiterm([-9 1 1 Q1_p],1,1);
lmiterm([-10 1 1 Q2_p],1,1);
lmiterm([-15 1 1 N1_p],1,1);
lmiterm([-17 1 1 N1211_p],r1,1);
lmiterm([-18 1 1 N1222_p],g1,1);
lmiterm([-19 1 1 N1233_p],u1,1);
lmiterm([-20 1 1 del_p],1,1);

lmisys=getlmis;
[tmin,xfeas]=feasp(lmisys);
tmin

N1_p=dec2mat(lmisys,xfeas,N1_p);
N11_p=dec2mat(lmisys,xfeas,N11_p);
N13_p=dec2mat(lmisys,xfeas,N13_p);
W3_p=dec2mat(lmisys,xfeas,W3_p);
Wtilde3_p=dec2mat(lmisys,xfeas,Wtilde3_p);
P1_p=dec2mat(lmisys,xfeas,P1_p);
P2_p=dec2mat(lmisys,xfeas,P2_p);
Q1_p=dec2mat(lmisys,xfeas,Q1_p);
Q2_p=dec2mat(lmisys,xfeas,Q2_p);

Ltilde_p=inv(N13_p)*W3_p;
Lpi_p=-Ltilde_p(1:n,1:q)
K2pi_p=Ltilde_p(n+q,1:q)
LLpi_p=Ltilde_p(n+q+q,1:q);
K1pi_p=pinv(Bf)*LLpi_p