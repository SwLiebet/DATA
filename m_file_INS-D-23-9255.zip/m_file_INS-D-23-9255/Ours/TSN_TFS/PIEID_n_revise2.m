r2=1; u2=1e+0; g2=210; e4=0.0003961;



% Matrices to be defined
setlmis([]);
[N11_n,n41,xn11_n]=lmivar(1,[n+q,1]);
[N1211_n,n41,xn1211_n]=lmivar(1,[n,1]);
[N1212_n,n41,xn1212_n]=lmivar(2,[n,q]);
[N1213_n,n41,xn1213_n]=lmivar(2,[n,q]);
[N1222_n,n41,xn1222_n]=lmivar(1,[q,1]);
[N1223_n,n41,xn1223_n]=lmivar(1,[q,1]);
[N1233_n,n41,xn1233_n]=lmivar(1,[q,1]);
[N13_n,n41,xn13_n]=lmivar(3,[xn1211_n,xn1212_n,xn1213_n;
                             xn1212_n',xn1222_n,xn1223_n;
                             xn1213_n',xn1223_n',xn1233_n]);
[N1_n,n41,xqp3_n]=lmivar(3,[xn11_n,zeros(n+q,n+q+q);
                            zeros(n+q+q,n+q),xn13_n]);
P1_n=lmivar(1,[n+q+n+q+q,1]); P2_n=lmivar(1,[n+q+n+q+q,1]);
Q1_n=lmivar(1,[n+q+n+q+q,1]); Q2_n=lmivar(1,[n+q+n+q+q,1]);
[W3_n,n43,xw_n]=lmivar(2,[n+q+q,q]); 
[Wtilde3_n,n43,xwtilde_n]=lmivar(3,[zeros(n,q);zeros(q);xw_n]);
del_n=lmivar(1,[1,1]);


lmiterm([1 1 1 Q1_n],1,1); 
lmiterm([1 1 1 N1_n],1,Atilde11,'s'); lmiterm([1 1 1 Wtilde3_n],1,Ctilde,'s');
lmiterm([1 1 2 N1_n],1,Adtilde11);
lmiterm([1 1 3 P1_n],1,1); lmiterm([1 1 3 N1_n],-1,1); 
lmiterm([1 1 3 -N1_n],Atilde11',e4); lmiterm([1 1 3 -Wtilde3_n],Ctilde',e4);
% lmiterm([1 1 4 N1_n],1,Mbar);
% lmiterm([1 1 5 del_n],1,N1bar11');
lmiterm([1 2 2 Q1_n],-1,1); 
lmiterm([1 2 3 N1_n],Adtilde11',e4);
% lmiterm([1 2 5 del_n],1,N2bar11');
lmiterm([1 3 3 N1_n],-e4,1,'s');
% lmiterm([1 3 4 N1_n],e4,Mbar);
% lmiterm([1 4 4 del_n],-1,1);
% lmiterm([1 5 5 del_n],-1,1);

lmiterm([2 1 1 Q2_n],1,1); 
lmiterm([2 1 1 N1_n],1,Atilde22,'s'); lmiterm([2 1 1 Wtilde3_n],1,Ctilde,'s');
lmiterm([2 1 2 N1_n],1,Adtilde22);
lmiterm([2 1 3 P2_n],1,1); lmiterm([2 1 3 N1_n],-1,1); 
lmiterm([2 1 3 -N1_n],Atilde22',e4); lmiterm([2 1 3 -Wtilde3_n],Ctilde',e4); 
% lmiterm([2 1 4 N1_n],1,Mbar);
% lmiterm([2 1 5 del_n],1,N1bar22');
lmiterm([2 2 2 Q2_n],-1,1); 
lmiterm([2 2 3 N1_n],Adtilde22',e4);
% lmiterm([2 2 5 del_n],1,N2bar22');
lmiterm([2 3 3 N1_n],-e4,1,'s');
% lmiterm([2 3 4 N1_n],e4,Mbar);
% lmiterm([2 4 4 del_n],-1,1);
% lmiterm([2 5 5 del_n],-1,1);

lmiterm([3 1 1 Q1_n],1,1); 
lmiterm([3 1 1 N1_n],1,Atilde12,'s'); lmiterm([3 1 1 Wtilde3_n],1,Ctilde,'s');
lmiterm([3 1 1 Q2_n],1,1); 
lmiterm([3 1 1 N1_n],1,Atilde21,'s'); lmiterm([3 1 1 Wtilde3_n],1,Ctilde,'s');
lmiterm([3 1 2 N1_n],1,Adtilde12); lmiterm([3 1 2 N1_n],1,Adtilde21);
lmiterm([3 1 3 P1_n],1,1); lmiterm([3 1 3 N1_n],-1,1); 
lmiterm([3 1 3 -N1_n],Atilde12',e4); lmiterm([3 1 3 -Wtilde3_n],Ctilde',e4); 
lmiterm([3 1 3 P2_n],1,1); lmiterm([3 1 3 N1_n],-1,1);
lmiterm([3 1 3 -N1_n],Atilde21',e4); lmiterm([3 1 3 -Wtilde3_n],Ctilde',e4);
% lmiterm([3 1 4 N1_n],1,Mbar); lmiterm([3 1 4 N1_n],1,Mbar);
% lmiterm([3 1 5 del_n],1,N1bar12'); lmiterm([3 1 5 del_n],1,N1bar21');
lmiterm([3 2 2 Q1_n],-1,1); lmiterm([3 2 2 Q2_n],-1,1);
lmiterm([3 2 3 N1_n],Adtilde12',e4); lmiterm([3 2 3 N1_n],Adtilde21',e4);
% lmiterm([3 2 5 del_n],1,N2bar12'); lmiterm([3 2 5 del_n],1,N2bar21');
lmiterm([3 3 3 N1_n],-e4,1,'s'); lmiterm([3 3 3 N1_n],-e4,1,'s');
% lmiterm([3 3 4 N1_n],e4,Mbar); lmiterm([3 3 4 N1_n],e4,Mbar);
% lmiterm([3 4 4 del_n],-1,1); lmiterm([3 4 4 del_n],-1,1);
% lmiterm([3 5 5 del_n],-1,1); lmiterm([3 5 5 del_n],-1,1);

lmiterm([-4 1 1 P1_n],1,1); lmiterm([-4 1 1 P2_n],-1,1);
lmiterm([-5 1 1 Q1_n],1,1); lmiterm([-5 1 1 Q2_n],-1,1);

lmiterm([-7 1 1 P1_n],1,1);
lmiterm([-8 1 1 P2_n],1,1);
lmiterm([-9 1 1 Q1_n],1,1);
lmiterm([-10 1 1 Q2_n],1,1);
lmiterm([-15 1 1 N1_n],1,1);
lmiterm([-17 1 1 N1211_n],r2,1);
lmiterm([-18 1 1 N1222_n],g2,1);
lmiterm([-19 1 1 N1233_n],u2,1);

lmisys=getlmis;
[tmin,xfeas]=feasp(lmisys);
tmin

N1_n=dec2mat(lmisys,xfeas,N1_n);
N13_n=dec2mat(lmisys,xfeas,N13_n);
W3_n=dec2mat(lmisys,xfeas,W3_n);
Wtilde3_n=dec2mat(lmisys,xfeas,Wtilde3_n);
P1_n=dec2mat(lmisys,xfeas,P1_n);
P2_n=dec2mat(lmisys,xfeas,P2_n);
Q1_n=dec2mat(lmisys,xfeas,Q1_n);
Q2_n=dec2mat(lmisys,xfeas,Q2_n);

Ltilde_n=inv(N13_n)*W3_n;
Lpi_n=-Ltilde_n(1:n,1:q)
K2pi_n=Ltilde_n(n+q,1:q)
LLpi_n=Ltilde_n(n+q+q,1:q);
K1pi_n=pinv(Bf)*LLpi_n