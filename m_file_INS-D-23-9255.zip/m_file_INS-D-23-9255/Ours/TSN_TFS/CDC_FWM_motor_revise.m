
A1 = [0 1; -9.2 -6.6];
A2 = [0 1; -10.8 -7.4];
B1 = [1; 0]; B2 = B1;
C = [0.4 0]; 

wc=100;

a1=1; b1=1862; e1=0.05996;


% cont1=ctrb(A1,B1);
% cont2=ctrb(A2,B2);
% obser1=obsv(A1,C);
% obser2=obsv(A2,C);
% c1=rank(cont1);
% c2=rank(cont2);
% o1=rank(obser1);
% o2=rank(obser2);

n=size(A1,1);
p=size(B1,2);
q=size(C,1);%���ά��
Abar1=[A1 zeros(n,q); -wc*C -wc];
Abar2=[A2 zeros(n,q); -wc*C -wc];
Bbar1=[B1; zeros(q)];
Bbar2=[B2; zeros(q)];
Adbar=[zeros(n,n) zeros(n,q); zeros(q,n) wc];


setlmis([]);
[M21,x1,xm21]=lmivar(1,[n,1]);
[M23,x1,xm23]=lmivar(1,[q,1]);
[M2,x1,xm2]=lmivar(3,[xm21,zeros(n,q);
                      zeros(q,n),xm23]);
[M31,x1,xm31]=lmivar(1,[n,1]);
[M33,x1,xm33]=lmivar(1,[q,1]);
[M3,x1,xm3]=lmivar(3,[xm31,zeros(n,q);
                      zeros(q,n),xm33]);
P=lmivar(1,[n+q,1]);
Q1=lmivar(1,[n+q,1]);
Q2=lmivar(1,[n+q,1]);
[W11,x1,wb11]=lmivar(2,[q,n]); [W12,x1,wb12]=lmivar(2,[q,n]);
Wbar11=lmivar(3,[wb11,zeros(q)]); Wbar12=lmivar(3,[wb12,zeros(q)]);
[W21,x1,wb21]=lmivar(1,[q,1]); [W22,x1,wb22]=lmivar(1,[q,1]);
Wbar21=lmivar(3,[zeros(q,n),wb21]); Wbar22=lmivar(3,[zeros(q,n),wb22]);

lmiterm([1 1 1 M2],-e1,1,'s'); 
lmiterm([1 1 2 P],1,1); lmiterm([1 1 2 M2],-1,1); 
lmiterm([1 1 2 M2],Abar1,e1); lmiterm([1 1 2 Wbar11],Bbar1,e1); 
lmiterm([1 1 3 M3],Adbar,e1); lmiterm([1 1 3 Wbar21],Bbar1,e1); lmiterm([1 1 3 M2],-1,1);
lmiterm([1 2 2 Q1],1,1); lmiterm([1 2 2 M2],Abar1,1,'s'); lmiterm([1 2 2 Wbar11],Bbar1,1,'s'); 
lmiterm([1 2 3 M3],Adbar,1); lmiterm([1 2 3 Wbar21],Bbar1,1); 
lmiterm([1 2 3 M2],1,Abar1'); lmiterm([1 2 3 -Wbar11],1,Bbar1'); 
lmiterm([1 3 3 Q2],-1,1); lmiterm([1 3 3 M3],Adbar,1,'s'); lmiterm([1 3 3 Wbar21],Bbar1,1,'s');

lmiterm([2 1 1 M2],-e1,1,'s'); 
lmiterm([2 1 2 P],1,1); lmiterm([2 1 2 M2],-1,1); 
lmiterm([2 1 2 M2],Abar2,e1); lmiterm([2 1 2 Wbar12],Bbar2,e1); 
lmiterm([2 1 3 M3],Adbar,e1); lmiterm([2 1 3 Wbar22],Bbar2,e1); lmiterm([2 1 3 M2],-1,1);
lmiterm([2 2 2 Q1],1,1); lmiterm([2 2 2 M2],Abar2,1,'s'); lmiterm([2 2 2 Wbar12],Bbar2,1,'s'); 
lmiterm([2 2 3 M3],Adbar,1); lmiterm([2 2 3 Wbar22],Bbar2,1); 
lmiterm([2 2 3 M2],1,Abar2'); lmiterm([2 2 3 -Wbar12],1,Bbar2'); 
lmiterm([2 3 3 Q2],-1,1); lmiterm([2 3 3 M3],Adbar,1,'s'); lmiterm([2 3 3 Wbar22],Bbar2,1,'s');

lmiterm([3 1 1 M2],-e1,1,'s'); lmiterm([3 1 1 M2],-e1,1,'s'); 
lmiterm([3 1 2 P],1,1); lmiterm([3 1 2 M2],-1,1); 
lmiterm([3 1 2 M2],Abar1,e1); lmiterm([3 1 2 Wbar12],Bbar1,e1); 
lmiterm([3 1 2 P],1,1); lmiterm([3 1 2 M2],-1,1);
lmiterm([3 1 2 M2],Abar2,e1); lmiterm([3 1 2 Wbar11],Bbar2,e1); 
lmiterm([3 1 3 M3],Adbar,e1); lmiterm([3 1 3 Wbar22],Bbar1,e1); lmiterm([3 1 3 M2],-1,1);
lmiterm([3 1 3 M3],Adbar,e1); lmiterm([3 1 3 Wbar21],Bbar2,e1); lmiterm([3 1 3 M2],-1,1);
lmiterm([3 2 2 Q1],1,1); lmiterm([3 2 2 M2],Abar1,1,'s'); lmiterm([3 2 2 Wbar12],Bbar1,1,'s'); 
lmiterm([3 2 2 Q1],1,1); lmiterm([3 2 2 M2],Abar2,1,'s'); lmiterm([3 2 2 Wbar11],Bbar2,1,'s');
lmiterm([3 2 3 M3],Adbar,1); lmiterm([3 2 3 Wbar22],Bbar1,1); 
lmiterm([3 2 3 M2],1,Abar1'); lmiterm([3 2 3 -Wbar12],1,Bbar1'); 
lmiterm([3 2 3 M3],Adbar,1); lmiterm([3 2 3 Wbar21],Bbar2,1); 
lmiterm([3 2 3 M2],1,Abar2'); lmiterm([3 2 3 -Wbar11],1,Bbar2'); 
lmiterm([3 3 3 Q2],-1,1); lmiterm([3 3 3 M3],Adbar,1,'s'); lmiterm([3 3 3 Wbar22],Bbar1,1,'s');
lmiterm([3 3 3 Q2],-1,1); lmiterm([3 3 3 M3],Adbar,1,'s'); lmiterm([3 3 3 Wbar21],Bbar2,1,'s');

lmiterm([-5 1 1 M2],1,1);
lmiterm([-6 1 1 M3],1,1);
lmiterm([-7 1 1 P],1,1);
lmiterm([-8 1 1 Q1],1,1);
lmiterm([-9 1 1 Q2],1,1);
lmiterm([-10 1 1 M21],a1,1);
lmiterm([-11 1 1 M33],b1,1);

lmisys=getlmis;
%Solver LMIs
[tmin,xfeas]=feasp(lmisys);
tmin

M2=dec2mat(lmisys,xfeas,M2);
M3=dec2mat(lmisys,xfeas,M3);
P=dec2mat(lmisys,xfeas,P);
Q1=dec2mat(lmisys,xfeas,Q1);
Q2=dec2mat(lmisys,xfeas,Q2);
Wbar11=dec2mat(lmisys,xfeas,Wbar11); Wbar12=dec2mat(lmisys,xfeas,Wbar12);
Wbar21=dec2mat(lmisys,xfeas,Wbar21); Wbar22=dec2mat(lmisys,xfeas,Wbar22);

Fe1=Wbar21*inv(M3);
Ke1=Fe1(1:q,n+q)
Fp1=Wbar11*inv(M2);
kp1=Fp1(1:q,1:n);
Kp1=kp1+Ke1*C

Fe2=Wbar22*inv(M3);
Ke2=Fe2(1:q,n+q)
Fp2=Wbar12*inv(M2);
kp2=Fp2(1:q,1:n);
Kp2=kp2+Ke2*C



