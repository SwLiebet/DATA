clc;clear;close all

A1 = [0 1; -9.2 -6.6];
A2 = [0 1; -10.8 -7.4];
B1 = [1; 0]; B2 = B1;
C = [0.4 0]; 
% alpha_p = 108.5; beta_p = 1407; delta_p = 0.05661;
alpha_p = 1e2; beta_p = 1.4e3; delta_p = 5.985e-2;


% %%% 7_motor 
% Jm = 2.8e-5; Bm = 20*Jm; 
% Fs = 3.25e-2; Fc = 1.76e-2; vs = 2.73; fv1 = 2.5e-4; fv2 = -9.252e-7; fv3 = 1.72e-9;
% A = -Bm/Jm; B = 1/Jm; 
% A1 = -Bm/Jm - fv1; 
% A2 = -Bm/Jm - fv1 - fv3*4900; 
% B1 = 1/Jm; B2 = 1/Jm;
% C = 1; 
% % alpha_p = 839.854359210119; beta_p = 6775.90893460887; delta_p = 0.0854044116598375; % ʵ��
% % alpha_p = 933.1; beta_p = 7561; delta_p = 0.1; % ʵ��
% alpha_p = 934; beta_p = 7562; delta_p = 0.1;  % ʵ��
% % alpha_p = 997; beta_p = 1e4; delta_p = 0.055;  % ʵ��


n = size(A1,1);
p = size(B1,2);
q = size(C,1);%���ά��

wc = 100;
Atilde1 = [A1 zeros(n,q); -wc*C -wc*eye(q)];
Atilde2 = [A2 zeros(n,q); -wc*C -wc*eye(q)];
Btilde1 = [B1; zeros(q,p)];
Btilde2 = [B2; zeros(q,p)];
Ad = [zeros(n) zeros(n,q); zeros(q,n) wc*eye(q)];

% Matrices to be defined
setlmis([]);
[E11_p,n1,xn11_p]=lmivar(1,[n,1]);
[E12_p,n1,xn12_p]=lmivar(1,[q,1]);
[E1_p,n1,xn1_p]=lmivar(3,[xn11_p,zeros(n,q);
                      zeros(q,n),xn12_p]);
[E21_p,n2,xn21_p]=lmivar(1,[n,1]);
[E22_p,n2,xn22_p]=lmivar(1,[q,1]);
[E2_p,n2,xn2_p]=lmivar(3,[xn21_p,zeros(n,q);
                      zeros(q,n),xn22_p]);
X1_p=lmivar(1,[n+q,1]); X2_p=lmivar(1,[n+q,1]);
Y1_p=lmivar(1,[n+q,1]); 
Y2_p=lmivar(1,[n+q,1]);
[W1_p,n3,wb2_p]=lmivar(2,[p,n]); Wbar1_p=lmivar(3,[wb2_p,zeros(p)]); 
[W2_p,n4,wb1_p]=lmivar(1,[p,1]); Wbar2_p=lmivar(3,[zeros(p,n),wb1_p]); 

%LMI conditions
lmiterm([1 1 1 Y1_p],1,1); lmiterm([1 1 1 E1_p],Atilde1,1,'s'); lmiterm([1 1 1 Wbar1_p],Btilde1,1,'s'); 
lmiterm([1 1 2 E2_p],Ad,1); lmiterm([1 1 2 Wbar2_p],Btilde1,1); lmiterm([1 1 2 -E1_p],1,Atilde1'); lmiterm([1 1 2 -Wbar1_p],1,Btilde1'); 
lmiterm([1 1 3 X1_p],1,1); lmiterm([1 1 3 E1_p],-1,1); lmiterm([1 1 3 E1_p],delta_p,Atilde1'); lmiterm([1 1 3 -Wbar1_p],delta_p,Btilde1');
lmiterm([1 2 2 Y2_p],-1,1); lmiterm([1 2 2 E2_p],Ad,1,'s'); lmiterm([1 2 2 Wbar2_p],Btilde1,1,'s'); 
lmiterm([1 2 3 E1_p],-1,1); lmiterm([1 2 3 E2_p],delta_p,Ad'); lmiterm([1 2 3 -Wbar2_p],delta_p,Btilde1');
lmiterm([1 3 3 E1_p],-delta_p,1,'s');

lmiterm([2 1 1 Y1_p],1,1); lmiterm([2 1 1 E1_p],Atilde2,1,'s'); lmiterm([2 1 1 Wbar1_p],Btilde2,1,'s'); 
lmiterm([2 1 2 E2_p],Ad,1); lmiterm([2 1 2 Wbar2_p],Btilde2,1); lmiterm([2 1 2 -E1_p],1,Atilde2'); lmiterm([2 1 2 -Wbar1_p],1,Btilde2'); 
lmiterm([2 1 3 X2_p],1,1); lmiterm([2 1 3 E1_p],-1,1); lmiterm([2 1 3 E1_p],delta_p,Atilde2'); lmiterm([2 1 3 -Wbar1_p],delta_p,Btilde2');
lmiterm([2 2 2 Y2_p],-1,1); lmiterm([2 2 2 E2_p],Ad,1,'s'); lmiterm([2 2 2 Wbar2_p],Btilde2,1,'s'); 
lmiterm([2 2 3 E1_p],-1,1); lmiterm([2 2 3 E2_p],delta_p,Ad'); lmiterm([2 2 3 -Wbar2_p],delta_p,Btilde2');
lmiterm([2 3 3 E1_p],-delta_p,1,'s');

lmiterm([4 1 1 X1_p],1,1); lmiterm([4 1 1 X2_p],1,-1);

lmiterm([-6 1 1 X1_p],1,1); 
lmiterm([-7 1 1 X2_p],1,1);
lmiterm([-8 1 1 Y1_p],1,1); 
lmiterm([-9 1 1 Y2_p],1,1);
lmiterm([-10 1 1 E1_p],1,1);
lmiterm([-5 1 1 E2_p],1,1);
lmiterm([-11 1 1 E11_p],alpha_p,1);
lmiterm([-12 1 1 E22_p],beta_p,1);

lmisys=getlmis;
[tmin,xfeas]=feasp(lmisys);
tmin
y1_p=tmin;

E1_p=dec2mat(lmisys,xfeas,E1_p);
E2_p=dec2mat(lmisys,xfeas,E2_p);
Wbar1_p=dec2mat(lmisys,xfeas,Wbar1_p); 
Wbar2_p=dec2mat(lmisys,xfeas,Wbar2_p); 
X1_p=dec2mat(lmisys,xfeas,X1_p);
X2_p=dec2mat(lmisys,xfeas,X2_p); 
Y1_p=dec2mat(lmisys,xfeas,Y1_p);
Y2_p=dec2mat(lmisys,xfeas,Y2_p); 

k1_p=Wbar2_p*inv(E2_p);
K1_p=k1_p(1:p,n+1)

k2_p=Wbar1_p*inv(E1_p);
K2_p = k2_p(1:p,1:n) + K1_p*C