
Kbar1_n = [K2_n - K1_n*C, zeros(q), -K2_n, zeros(q)];
Gbar1_n = Abar1 + Bbar1*Kbar1_n;
Gbar2_n = Abar2 + Bbar2*Kbar1_n;
eig(Gbar1_n);
eig(Gbar2_n);
Kbar2_n = [zeros(q,n), K1_n, zeros(q,n), zeros(q)];
Dbar1_n = Adbar + Bbar1*Kbar2_n;
Dbar2_n = Adbar + Bbar2*Kbar2_n;


gamma_n = 1e1; mu_n = 1e6; epsilon_n = 1e-3; psi_n = 1e0; %WYC_TFS


% gamma_n = 7e4; mu_n = 1e0; epsilon_n = 1e-5; psi_n = 9e0; % ʵ��



% Matrices to be defined
setlmis([]);
S1_n=lmivar(1,[2*n+2*q,1]); S2_n=lmivar(1,[2*n+2*q,1]);
R_n=lmivar(1,[2*n+2*q,1]); 
[Z41_n,n3,xqp31_n]=lmivar(1,[n+q,1]);
[Z433_n,n3,xqp333_n]=lmivar(1,[n,1]);
[Z434_n,n3,xqp334_n]=lmivar(2,[n,q]);
[Z444_n,n3,xqp344_n]=lmivar(1,[q,1]);
[Z42_n,n3,xqp32_n]=lmivar(3,[xqp333_n,xqp334_n;xqp334_n',xqp344_n]);
[Z4_n,n3,xqp3_n]=lmivar(3,[xqp31_n,zeros(n+q,n+q);
                      zeros(n+q,n+q),xqp32_n]);
[W3_n,n3,xqpw_n]=lmivar(2,[n+q,q]); 
[Wbar3_n,n3,xqpwbar_n]=lmivar(3,[zeros(n+q,q);xqpw_n]);

%LMI conditions
lmiterm([1 1 1 R_n],1,1); lmiterm([1 1 1 Z4_n],psi_n,Gbar1_n,'s'); lmiterm([1 1 1 Wbar3_n],psi_n,Cbar,'s'); 
lmiterm([1 1 2 Z4_n],psi_n,Dbar1_n);
lmiterm([1 1 3 S1_n],1,1); lmiterm([1 1 3 Z4_n],-1,psi_n); 
lmiterm([1 1 3 -Z4_n],Gbar1_n',epsilon_n*psi_n); lmiterm([1 1 3 -Wbar3_n],Cbar',epsilon_n*psi_n); 
lmiterm([1 2 2 R_n],-1,1);
lmiterm([1 2 3 -Z4_n],Dbar1_n',epsilon_n*psi_n);
lmiterm([1 3 3 Z4_n],-epsilon_n,psi_n,'s');

lmiterm([2 1 1 R_n],1,1); lmiterm([2 1 1 Z4_n],psi_n,Gbar2_n,'s'); lmiterm([2 1 1 Wbar3_n],psi_n,Cbar,'s'); 
lmiterm([2 1 2 Z4_n],psi_n,Dbar2_n);
lmiterm([2 1 3 S1_n],1,1); lmiterm([2 1 3 Z4_n],-1,psi_n); 
lmiterm([2 1 3 -Z4_n],Gbar2_n',epsilon_n*psi_n); lmiterm([2 1 3 -Wbar3_n],Cbar',epsilon_n*psi_n); 
lmiterm([2 2 2 R_n],-1,1);
lmiterm([2 2 3 -Z4_n],Dbar2_n',epsilon_n*psi_n);
lmiterm([2 3 3 Z4_n],-epsilon_n,psi_n,'s');

lmiterm([-4 1 1 S1_n],1,1); lmiterm([-4 1 1 S2_n],-1,1);

lmiterm([-6 1 1 S1_n],1,1);
lmiterm([-7 1 1 S2_n],1,1);
lmiterm([-8 1 1 R_n],1,1);
lmiterm([-10 1 1 Z4_n],1,1);
lmiterm([-11 1 1 Z41_n],1,1);
lmiterm([-12 1 1 Z433_n],gamma_n,1);
lmiterm([-13 1 1 Z444_n],mu_n,1);

lmisys=getlmis;
[tmin,xfeas]=feasp(lmisys);
tmin
y2_n=tmin;

S1_n=dec2mat(lmisys,xfeas,S1_n); S2_n=dec2mat(lmisys,xfeas,S2_n); 
R_n=dec2mat(lmisys,xfeas,R_n); 
Z4_n=dec2mat(lmisys,xfeas,Z4_n);
Z41_n=dec2mat(lmisys,xfeas,Z41_n);
Z42_n=dec2mat(lmisys,xfeas,Z42_n);
Z433_n=dec2mat(lmisys,xfeas,Z433_n);
Z444_n=dec2mat(lmisys,xfeas,Z444_n);
Wbar3_n=dec2mat(lmisys,xfeas,Wbar3_n);
W3_n=dec2mat(lmisys,xfeas,W3_n);

L0_n=inv(Z42_n)*W3_n;
L_n=-L0_n(1:n,1:q)
LL_n=L0_n(n+1,1:q);
K_n=inv(BF)*LL_n
